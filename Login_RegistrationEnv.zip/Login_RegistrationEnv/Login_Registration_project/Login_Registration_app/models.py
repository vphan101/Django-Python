from django.db import models
import re  # the regex module
import bcrypt

# Create your models here.
class UserManager(models.Manager):
    def register_validator(self, postal_dataz):
        errors = {}
    # if/else statements
    # alias < 3
        if len(postal_dataz['register_alias']) < 3:
            errors['register_alias'] = "Your alias needs to be at least 3 characters"
    
    # email format
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9]+$')
        
        if not EMAIL_REGEX.match(postal_dataz['register_email']):
            errors['register_email'] = "Invalid email address!"
    
    # password confirm
        if postal_dataz['register_password'] != postal_dataz['register_password_confirm']:
            errors['register_password'] = "Password does not match"
        if len(postal_dataz['register_password']) < 8:
            errors['register_password_confirm'] = "Password is too short"
    
        
        return errors

    def login_validator(self, postal_dataz):
        errors = {}
    # if/else statements
    # email matches a user
        user_list_to_login = User.objects.filter(email = postal_dataz['login_email'])
        if len(user_list_to_login) == 0:
            print('We did not find a user')
            # password matches the user.email
            errors['login_email'] = "There was a problem with the email"
        else:
            if not bcrypt.checkpw(postal_dataz['login_password'].encode(), 
            user_list_to_login[0].password.encode()):
                print('Password does not match')
                errors['login_password'] = "There was a problem with the password"

        return errors


class User(models.Model):
    alias = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()