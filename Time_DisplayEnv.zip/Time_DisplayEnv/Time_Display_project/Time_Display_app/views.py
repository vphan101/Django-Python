from django.shortcuts import render, redirect # 1) HttpResponse
from time import gmtime, strftime


#def index(request):
#    # 1) return HttpResponse("<h1>Hello Time Display, from the Django Server</h1>")
#    print(request)
   
#    name = "Vinh"
#    context = {
#        'user_name': name
#    }
#    return render(request, "index.html", context)


def index(request):
    context = {
        "time": strftime("%Y-%m-%d %H:%M %p", gmtime())
    }
    return render(request,'index.html', context)