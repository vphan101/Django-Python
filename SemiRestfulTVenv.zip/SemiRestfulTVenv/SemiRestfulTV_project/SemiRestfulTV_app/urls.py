from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('new', views.new_show),
    path('', views.go_back),
    path('show', views.show),
    path('edit', views.edit),
    

    path('users/create',views.users_create),


]
