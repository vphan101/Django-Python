from django.apps import AppConfig


class SemirestfultvAppConfig(AppConfig):
    name = 'SemiRestfulTV_app'
