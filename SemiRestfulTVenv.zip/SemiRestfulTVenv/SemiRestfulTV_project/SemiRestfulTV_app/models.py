

from django.db import models
import re

class CustomManager(models.Manager):
    def basic_validatorzzz(self, user_data):
        print('user_data inside CustoManager: ', user_data)
        errors = {}
        if len(user_data["title"]) < 1:
            errors["error_title"] = "Enter your Title"
        elif not re.compile(r'[a-zA-Z0-9+-_]+@[a-zA-Z0-9+-_]+.[a-zA-Z0-9]+').match(user_data["email"]):
            errors["error_network"] = "Enter valid Network"
    
        return errors

class User(models.Model):
    Id = models.CharField(max_length = 255)
    title = models.CharField(max_length = 255)
    network = models.CharField(max_length = 255)
    release_date = models.IntegerField(default=0)
    actions = models.CharField(max_length = 255)
    
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = CustomManager()

    
