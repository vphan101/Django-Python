from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *

def index(request):
    return render(request, "index.html")

def new_show(request):
    
    return render(request, "new.html")

def go_back(request):
    return render(request,"index.html")

def show(request):
    return render(request, "show.html")

def edit(request):
    return render(request, "edit.html")




def users_create(request):
    print(request.POST)
    # validate post data
    errors = Users.objects.basic_validatorzzz(request.POST)
    print(errors)
    if len(errors) > 0:
        # if the errors dictionary contains anything, loop through each key-value pair and make a flash message
        for key, value in errors.items():
            messages.error(request, value)
        # redirect the user back to the form to fix the errors
        return redirect('/index')

    else:
        # create an album
        Users.objects.create(
            Id = request.POST('id'),
            title=request.POST['title'],
            network = request.POST['network'],
            release_year = request.POST['release_year'],
            actions = request.POST['description']
        )
        return redirect('/index')



