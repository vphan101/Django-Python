from django.shortcuts import render, redirect
from django.contrib import messages
from . models import *
import bcrypt
# * means all .models import User, Comment, Messages



def index(request):
    return render(request, 'index.html')

def wall(request):
    if 'uuid' not in request.session:
        return redirect('/')
    user_id = request.session['uuid']
    context ={
        'user': User.objects.get(id=user_id)
    }
    return render(request, 'wall.html', context)

def register(request):
    print(request.POST)

    errors = User.objects.register_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        # redirect the user back to the form to fix the errors
        return redirect('/')

    else:
        # create the user
        print('registering a user')
        password = request.POST['register_password']
        hash_browns = bcrypt.hashpw(
            password.encode(), bcrypt.gensalt()).decode()
        
        print('password:', password)
        print('hash_browns:', hash_browns)
        user = User.objects.create(
            first_name = request.POST['register_first_name'],
            last_name = request.POST['register_last_name'],
            email = request.POST['register_email'],
            password = hash_browns
        )

        request.session['uuid'] = user.id
        return redirect('/wall')
    
def logout(request):
    request.session.flush()
    return redirect('/')

def login(request):
    print(request.POST)
    errors = User.objects.login_validator(request.POST)
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user_to_login = User.objects.get(
            email=request.POST['login_email'])
        print('user_to_login: ', user_to_login)
        request.session['uuid'] = user_to_login.id
        return redirect('/wall')

        
    

