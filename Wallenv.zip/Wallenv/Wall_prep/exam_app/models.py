from django.db import models
import re
import bcrypt

    

class UserManager(models.Manager):
    def register_validator(self, postal_dataz):
        errors ={}

        if len(postal_dataz['register_first_name'])< 2:
            errors['register_first_name'] = "Your first name needs to be at least 3 characters"

        if len(postal_dataz['register_last_name'])< 2:
            errors['register_last_name'] = "Your last name needs to be at least 3 characters"
            
        EMAIL_REGEX = re.compile(
            r'^[a-zA-Z0-9.+_-]+ @[a-zA-Z0-9._-]+\[a-zA-Z]+$')
        
        print(EMAIL_REGEX.match(postal_dataz['register_email']))
        if not EMAIL_REGEX.match(postal_dataz['register_email']) == None:
            errors['register_email'] = "Invalid email address!"

        if postal_dataz['register_password'] != postal_dataz['register_password_confirm']:
            errors['register_password'] = "Password does not match"

        if len(postal_dataz['register_password']) < 9:
            errors['register_password_confirm'] = 'Password is too short, must be at least 9 characters'

        
        return errors

    def login_validators(self, postal_dataz):
        error = {}

        user_list_to_login = User.objects.filter(
            email=postal_dataz['login_email']
        )

        if len(user_list_to_login) == 0:
            print('we did not find a user')
            errors['login_email'] = 'There was a problem email'
        else:
            if not bcrypt.checkpw(postal_dataz['login_password'].encode(), user_list_to_login[0]
            .password.encode()):
                print('Password does not match')
                errors['login_password'] = 'There was a problem pw'

        return errors

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
   
    objects = UserManager()
    