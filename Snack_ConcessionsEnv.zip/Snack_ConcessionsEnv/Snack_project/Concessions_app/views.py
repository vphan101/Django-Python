from django.shortcuts import render, redirect
from . models import Item, Supplier


def index(request):
    context = {
        'all_items': Item.objects.all(),
        'all_suppliers': Supplier.objects.all()
    }
    print(context['all_items'])
    return render(request, "index.html", context)

def add_item_to_inventory(request):
    print(request.POST)

    supplier_id = request.POST['supplier']
    supplier_instance = Supplier.objects.get(id=supplier_id)

    # add item to Database
    Item.objects.create(
        item_name = request.POST['item_name'],
        description = request.POST['description'],
        size = request.POST['size'],
        quantity = request.POST['quantity'],
        price = request.POST['price'],
        vendor = supplier_instance
    )

    return redirect('/')

def add_supplier(request):
    print(request.POST)

    new_supplier = Supplier.objects.create(
        name = request.POST['supplier']
    )

    print('We created a supplier!', new_supplier)
    return redirect('/')

    supplier_id = request.POST['supplier']






