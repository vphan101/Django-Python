from django.apps import AppConfig


class ConcessionsAppConfig(AppConfig):
    name = 'Concessions_app'
