from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index),
    path('processform', views.processform),
    path('results', views.formresults),
    path('reset', views.resetsession),
]