from django.shortcuts import render, redirect,HttpResponse


def index(request):
    return render(request, "index.html")


def processform(request):
    if request.method != 'POST':
        return redirect('/')
    request.session['first_name'] = request.POST['first_name']
    request.session['last_name'] = request.POST['last_name']
    request.session['Location'] = request.POST['Location']
    request.session['language'] = request.POST['language']
    request.session['text'] = request.POST['text']
    #return HttpResponse("form submitted")
    return redirect('/results')

def formresults(request):
    return render(request, 'results.html')

def resetsession(request):
    request.session.clear()
    return redirect('/')