from django.apps import AppConfig


class PostFormAppConfig(AppConfig):
    name = 'Post_Form_app'
