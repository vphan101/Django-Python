from django.urls import path
from . import views

urlpatterns = [
    path('', views.index ),
    path('register', views.register),
    path('login', views.login),
    path('wish', views.wish),
    path('logout', views.logout),

    path('make', views.make_wish),
    path('stats', views.stats),
    path('Edit', views.edit),

]


#path('register', views.register),
#    path('wish', views.wish),
#    path('logout', views.logout),
#    path('login', views.login),
#    path('messages/create', views.messages_create),
#    path('make', views.make_wish),
#    path('Edit', views.Edit),

