from django.apps import AppConfig


class WishAppConfig(AppConfig):
    name = 'Wish_app'
