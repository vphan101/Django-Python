from django.db import models


class Artist(models.Model):
    alias = models.CharField(max_length=255)
    # albums
    # tracks
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Track(models.Model):
    name = models.CharField(max_length=255)
    # artists
    # albums
    artists = models.ManyToManyField('Artist', related_name='tracks')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class AlbumManager(models.Manager):
    def basic_validatorzzz(self, post_data):
        print('post_data inside AlbumManager: ', post_data)
        errors = {}
        # if add keys and values to errors dictionary for each invalid field
        if len(post_data['title']) < 5:
            errors['title'] = "Title name should be at least 5 characters"
        return errors


class Album(models.Model):
    title = models.CharField(max_length=255)
    release_year = models.IntegerField(default=0)
    artists = models.ManyToManyField('Artist', related_name='albums')
    tracks = models.ManyToManyField('Track', related_name= 'albums')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = AlbumManager()





    