from django.apps import AppConfig


class RecordStoreAppConfig(AppConfig):
    name = 'record_store_app'
