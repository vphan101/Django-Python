from django.shortcuts import render, redirect
from . models import *
from django.contrib import messages

# render functions
def index(request):
    return render(request, "index.html")

def albums(request):
    context = {
        "all_albums": Album.objects.all(),
        "all_artists": Artist.objects.all(),
        "all_tracks": Track.objects.all(),
    }
    return render(request, 'albums.html', context)


def artists(request):
    context = {
        "all_artists": Artist.objects.all()
    }
    return render(request, 'artists.html', context)

def tracks(request):
    context = {
        "all_tracks": Track.objects.all()
    }
    return render(request, 'tracks.html', context)

# redirect functions
def albums_create(request):
    print(request.POST)
    # validate post data
    errors = Album.objects.basic_validatorzzz(request.POST)
    print(errors)
    if len(errors) > 0:
        # if the errors dictionary contains anything, loop through each key-value pair and make a flash message
        for key, value in errors.items():
            messages.error(request, value)
        # redirect the user back to the form to fix the errors
        return redirect('/albums')

    else:
        # create an album
        Album.objects.create(
            title=request.POST['title']
        )
        return redirect('/albums')

def artists_create(request):
    print(request.POST)
   
    Artist.objects.create(
        alias=request.POST['alias']
    )
    return redirect('/artists')

def tracks_create(request):
    print(request.POST)

    Track.objects.create(
        name= request.POST['name']
    )
    return redirect('/tracks')

def albums_add_artists(request):
    print(request.POST)
    # how do we add an artist to an album
    artist_id = request.POST['artist']
    artist_to_add = Artist.objects.get(id=artist_id)
    
    album_id = request.POST['album']
    album_to_add = Album.objects.get(id=album_id)
    
    print(artist_to_add, album_to_add)
    album_to_add.artists.add(artist_to_add)

    return redirect('/albums')
