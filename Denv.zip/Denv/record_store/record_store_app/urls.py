from django.urls import path
from . import views

urlpatterns = [
    #render routes
    path('', views.index),
    path('albums', views.albums),
    path('artists', views.artists),
    path('tracks', views.tracks),

    # redirect routes
    path('albums/create',views.albums_create),
    path('artists/create', views.artists_create),
    path('tracks/create', views.tracks_create),
    path('albums/add_artists', views.albums_add_artists),
]