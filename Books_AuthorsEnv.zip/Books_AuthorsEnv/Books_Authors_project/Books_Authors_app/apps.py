from django.apps import AppConfig


class BooksAuthorsAppConfig(AppConfig):
    name = 'Books_Authors_app'
