from django.shortcuts import render, redirect


def index(request):

    if 'username' in request.session:
        return redirect('/dashboard')
    else:
        return render(request, 'index.html')



def register(request):

    request.session['username'] = request.POST['username']

    request.session['times_seen'] = 0

    return redirect('/dashboard')


def dashboard(request):
    print(request.session)

    # check if we have a user in session

    if 'username' in request.session:

        request.session['times_seen'] += 1

        context = {
            'usernaMee': request.session['username']
        }
        return render(request, 'dashboard.html', context)
    
    else:
        return redirect('/')


def logout(request):
    # reset the session
    
    #del request.session['username']
    #del request.session['times_seen']

    request.session.clear()
    return redirect('/')